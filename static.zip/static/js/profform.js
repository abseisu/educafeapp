$(".datetime").on("change keyup paste", function () {
    if ($(this).val()) {
      $(".icon-paper-plane").addClass("next");
    } else {
      $(".icon-paper-plane").removeClass("next");
    }
  });
  
  $(".next-button").hover(function () {
    $(this).css("cursor", "pointer");
  });
  
  $(".next-button.datetime").click(function () {
    console.log("Something");
    $(".datetime-section").addClass("fold-up");
    $(".location-section").removeClass("folded");
  });
  
  $(".location").on("change keyup paste", function () {
    if ($(this).val()) {
      $(".icon-lock").addClass("next");
    } else {
      $(".icon-lock").removeClass("next");
    }
  });
  
  $(".next-button").hover(function () {
    $(this).css("cursor", "pointer");
  });
  
  $(".next-button.location").click(function () {
    console.log("Something");
    $(".location-section").addClass("fold-up");
    $(".capacity-section").removeClass("folded");
  });
  
  $(".capacity").on("change keyup paste", function () {
    if ($(this).val()) {
      $(".icon-repeat-lock").addClass("next");
    } else {
      $(".icon-repeat-lock").removeClass("next");
    }
  });
  
  $(".next-button").hover(function () {
    $(this).css("cursor", "pointer");
  });

  $(".next-button.capacity").click(function () {
    console.log("Something");
    $(".capacity-section").addClass("fold-up");
    $(".topic-section").removeClass("folded");
  });
  
  $(".topic").on("change keyup paste", function () {
    if ($(this).val()) {
      $(".icon-comm").addClass("next");
    } else {
      $(".icon-comm").removeClass("next");
    }
  });
  
  $(".next-button.topic").click(function () {
    console.log("Something");
    $(".topic-section").addClass("fold-up");
    $(".success").css("marginTop", 0);
  });
  