/**
 * jTinder initialization
 */
 $("#tinderslide").jTinder({
	// dislike callback
    onDislike: function (item) {
		document = "swipes.html";
		document.getElementById('swipe_left').submit();
    },
	// like callback
    onLike: function (item) {
		document = "swipes.html";
		document.getElementById('swipe_right').submit();
    },
	animationRevertSpeed: 200,
	animationSpeed: 100,
	threshold: 1,
	likeSelector: '.like',
	dislikeSelector: '.dislike'
});

/**
 * Set button action to trigger jTinder like & dislike.
 */
$('.actions .like, .actions .dislike').click(function(e){
	e.preventDefault();
	$("#tinderslide").jTinder($(this).attr('class'));
});